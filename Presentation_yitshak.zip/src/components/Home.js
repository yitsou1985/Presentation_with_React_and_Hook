import React,{Component} from "react";
import "./Home";

const Home = ()=>{
    return(
        <div className="container">
            <h1>Home</h1>
            <h4>I'm a React js Web Developer </h4>
            <h4>and looking for a new challenge</h4>
        </div>
    )
}
export default Home;