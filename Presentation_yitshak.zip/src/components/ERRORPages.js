import React from 'react';


function ERRORPages(){
  return(
    <div className="container">
    <h1>Page Not Found</h1>
    </div>
  )
}



export default ERRORPages;